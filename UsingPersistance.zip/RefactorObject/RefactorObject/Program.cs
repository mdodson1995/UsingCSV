﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorObject
{
    class Program
    {
        enum DayOfWeek
        {
            Monday,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday,
            Sunday
        }
        static void Main(string[] args)
        {
            Welcome();
            Menu();
        }
        private static void Welcome()
        {
            Console.WriteLine("Hello. Welcome to the list.");
            Console.WriteLine("Press a key to continue.");
            Console.ReadLine();
        }
        private static void Closing()
        {
            Console.WriteLine("Goodbye.");
            Environment.Exit(5);
        }

        private static void Menu()
        {
            string userResponse;
            //int userChoice;
            Console.WriteLine("Menu");
            Console.WriteLine("1. Create Record.");
            Console.WriteLine("2. View List.");
            Console.WriteLine("3. Update Record.");
            Console.WriteLine("4. Delete Record.");
            Console.WriteLine("Enter your response now: ");
            userResponse = Console.ReadLine();

            switch (userResponse)
            {
                case "1":
                    MakeList();
                    break;
                case "2":
                    View();
                    break;
                case "3":
                    Update();
                    break;
                case "4":
                    Delete();
                    break;
                default:
                    break;
            }
        }
        public static void MakeList()
        {


            StringBuilder csv = new StringBuilder();
            Console.Clear();
            Console.WriteLine("Enter your name: ");
            var name = Console.ReadLine();

            Console.WriteLine("Enter your age: ");
            var age = Console.ReadLine();

            Console.WriteLine("Enter your phone number: ");
            var phone = Console.ReadLine();

            Console.WriteLine("What day of the week does your birthday fall on?: ");
            var day = DayOfWeek.Sunday;

            Console.Clear();
            csv.AppendLine("Name: " + name);
            csv.AppendLine("Age: " + age);
            csv.AppendLine("Phone Number: " + phone);
            csv.AppendLine("Day of Week: " + day);
            string path = "C:\\Users\\Mathew\\Desktop\\CIT255\\Projects\\RefactorObject\\RefactorObject\\data\\content.csv";
            File.AppendAllText(path, csv.ToString());
            Console.WriteLine(csv);
            Console.WriteLine();
            Console.WriteLine("Press a key to continue.");
            Console.ReadKey();
            Console.WriteLine("Would you like to add another record? yes/no");
            string ans = Console.ReadLine();
            if (ans == "yes")
            {
                MakeList();
                csv.Append(name);
                csv.Append(age);
                csv.Append(phone);
                csv.Append(day);
                Console.Clear();  
            }
            else
            {

                Console.WriteLine("Would you like to go back to menu? yes/no");
                string answer = Console.ReadLine();
                if (answer == "yes")
                {

                    Console.Clear();
                    Menu();

                }
                else
                {
                    Closing();
                }
            }
        }


        private static void View()
        {

        }
        private static void Update()
        {

        }
        private static void Delete()
        {
            string path = "C:\\Users\\Mathew\\Desktop\\CIT255\\Projects\\RefactorObject\\RefactorObject\\data\\content.csv";
            Console.WriteLine("Would you like to delete this file?yes/no ");
            var ans = Console.ReadLine();
            if (ans == "yes")
            {
                File.Delete(path);
                Console.WriteLine("File deleted.");
                Console.WriteLine("Press a key to continue.");
                Console.ReadKey();
                Console.Clear();
                Menu();
            }
            else
            {
                Console.WriteLine("Going back to Menu. Press a key to continue.");
                Console.ReadKey();
                Console.Clear();
                Menu();
            }
        }
    }
}
